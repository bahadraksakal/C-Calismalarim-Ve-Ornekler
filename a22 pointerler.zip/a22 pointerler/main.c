#include <stdio.h>
#include <stdlib.h>

int main()
{
    int tam=33;
   // printf("icerik : %d \n", tam); // icreki =33;
    //printf("adres : %p \n", &tam); //adres =000000000060FE1C
    // %p onaltilik sistemde gosterir.
    //scanf("%d",&tam); // bir int al ve bunu &tam adresine ata.
    //pointer tanimlama : int *isretci_adi  (int yerine herhangi bir degisken atanabilir.)
    // veri tipi neyse onunla ilgili pointer da ayni tipte tanimlanmalidir.
    int a=541; // pointerler adlandirilirken sonuna ptr alir ahlak kurallari geregi.
    int *aptr; // aptr, bir pointerdir.
    aptr=&a; //artik ; aptr, a'nin fiziksel adresini tutar.
    // * sadece pointer ilk tanimlarken basina konulur.
    printf("aptr'nin degeri:(adres)%p \n",aptr);
    printf("aptr'nin degeri:(adresteki deger)%d \n",*aptr);
    /* pointer tanimlarken *
       value at (de-referancing) *
       adress of (referancing) &
    */
    //
    printf("\n\n");
    //
    *aptr=44; //aptr adresindeki deðere 44 ata.
    printf("aptr'nin degeri:(adres)%p \n",aptr);
    printf("aptr'nin degeri:(adres)%p \n",&tam);
    printf(" *aptr'nin yeni degeri:(value) %d \n",*aptr);
    printf(" tam'in yeni degeri:(value) %d \n",tam);
    //
    printf("\n\n");
    //
    const int b=35;
    printf(" b(value) %d \n",b);
    int *adresptr;
    adresptr=&b;
    *adresptr=500;
//    *&b=500;
    printf(" b(value) yenideger %d \n",b);
    printf(" b(adress) %p \n",adresptr);
    printf(" b(adress) %p \n",&b);
    //
    printf("\n\n");
    //
    int c=322;
    char *cptr=&a; // pointerlerde aritmatik islemler yapilabilir
    printf("c----> %p \n",cptr);
    printf("c----> 0 // %d \n",*cptr);
    cptr++;  // 1 byte tutar  1 arttir demektir
    printf("c----> 1 // %d \n",*cptr);
     cptr++;
    printf("c----> 2  // %d \n",*cptr);
     cptr++;
    printf("c----> 3  // %d \n",*cptr);
    //
    printf("\n\n");
    //
    //NULL ÝSARETCÝ , ADRES BOS MY DOLUMU ANLAMAK ÝCÝN KULLANÝLABÝLÝR
    int *kptr; // null 0. adresi temsil eder   atama yaparsak hata aliriz.
    kptr=NULL; // tüm iþletim sistemlerinde 0 adresi yasaklidir ddegistirilemez.
    printf("");
    //
    printf("\n\n");
    //
    int y=123;
    int *yptr;
    yptr=&y;
    printf("%p \n",yptr);
    yptr++;// yptr int oldugundan  ve int en az 4 bye aldiginde int 4 arttirilir.
    printf("%p \n",yptr);
    // doubleyi double+=5 yapmak sizeof(double)*5  kadar arttir demek.
    //
    printf("\n\n");
    //
    // %u onluk tabanda okur. %p 16 lık tabanda okur.
    int dizi[5]={1,2,3,4,5};
    int *dptr=&dizi;
    printf("%u , %u , %u \n", &dizi , dizi , *dizi);// dizi aslinda bir pointerdir.
    printf("%u , %u , %u \n", &dptr , dptr , *(dptr+1),&*(dptr+1)); // pointer in turunun cinsi ne ise o miktarrda artar
    //&*(dptr+1))    2. elemanin ram deki adresini verir.





    return 0;
}
